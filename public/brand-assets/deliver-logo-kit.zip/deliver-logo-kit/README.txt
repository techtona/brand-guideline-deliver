DELIVER — LOGO KIT
==================

Isi folder
----------
svg/       Vektor master. Pakai ini untuk desain digital, Figma, Illustrator, web.
pdf/       Vektor untuk cetak / percetakan (bisa dibuka & diedit di Illustrator).
png/       Raster transparan siap pakai (lebar dalam px tertera di nama file).
app-icon/  Simbol di atas tile persegi untuk avatar sosial media & app icon.

Varian
------
logo-*     Lockup lengkap: simbol ayam jago berbentuk "D" + wordmark DELIVER.
symbol-*   Simbol saja — untuk ruang sempit, avatar, favicon, watermark.

primary     Warna penuh, untuk latar terang (putih / off-white / netral terang).
reverse     Warna penuh dengan huruf off-white, untuk latar gelap.
mono-black  Satu warna hitam — cetak satu warna, stempel, emboss, fax.
mono-white  Satu warna putih — di atas foto atau latar warna gelap/merah.

Warna logo
----------
Hitam        #000000
Merah        #EE141F
Kuning       #FBB13F
Off-white    #F6F4F0   (huruf pada versi reverse)

Aturan singkat
--------------
- Clear space minimal setinggi huruf "D" di setiap sisi (tidak dibakar ke file).
- Ukuran minimum: digital 160 px lebar, cetak 26 mm lebar.
- Jangan ubah warna, proporsi, efek bayangan, atau memutar logo.

Catatan teknis
--------------
Vektor ini hasil auto-trace dari PNG resmi 669 x 205 px (belum ada file master
dari desainer). Bentuknya sudah dirapikan dan aman untuk web, presentasi, sosmed,
dan cetak ukuran umum (kartu nama, kop surat, kemasan, banner). Untuk cetak sangat
besar (billboard, signage, sablon besar), minta desainer me-redraw kurva dari file
SVG ini agar garis tepinya benar-benar mulus.
