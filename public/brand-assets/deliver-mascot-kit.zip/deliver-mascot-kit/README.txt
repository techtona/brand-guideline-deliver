DELIVER — MASKOT
================

File
----
deliver-mascot-thumbs-up.png      Pose jempol + lap, resolusi penuh (PNG transparan)
deliver-mascot-thumbs-up-600.png  Versi 600 px untuk web / sosmed
deliver-mascot-wink.png           Pose kedip + jempol, resolusi penuh (PNG transparan)
deliver-mascot-wink-600.png       Versi 600 px untuk web / sosmed

Kapan dipakai
-------------
- Konten sosial media, edukasi peternak, onboarding aplikasi
- Stiker, merchandise, sapaan dan pengumuman yang ramah

Jangan
------
- Dipakai di dokumen formal: kontrak, laporan keuangan, proposal resmi
- Menggantikan logo Deliver (maskot pendamping, bukan logo)
- Mengubah warna, proporsi, atau memotong bagian tubuh maskot
- Diletakkan di atas foto yang ramai sampai garis tepinya hilang

Catatan: resolusi maksimum mengikuti gambar sumber; untuk cetak besar
(banner, baliho) minta ilustrator membuat versi vektor.
